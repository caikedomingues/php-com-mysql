



<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta hhttp-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <title> Php com banco de dados</title>
        <link rel="shotcuts icon" href="imagens/simbolo.png">
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>

    <body>
        <header>
            <h1>Php com banco mysql</h1>
        </header>

        <main>
            
                <p><a href="cadastro.php">Cadastro</a></p>
                <p><a href="apagar.php">Apagar</a></p>
                <p><a href="pesquisar.php">Pesquisar usuário</a></p>
                <p><a href="index.html">Voltar a página inicial</a></p>

        </main>

        <section>

            <?php
            
                $cpf = $_GET['cpf'] ?? 0;
                $nome = $_GET['nome'] ?? "desconhecido";
                $email = $_GET['email'] ?? "não informado";
                $sexo = $_GET['sexo'] ?? "Não informado";
            
            ?>

            <form action = "<?php $_SERVER=['PHP_SELF']?>" method ="get">

                <label for="cpf">Informe o cpf que terá os dados alterados</label>

                <input type="number" name="cpf" id="idcpf" required autocomplete="off">

                <label for="nome"> Novo nome: </label>
                <input type="text" name = "nome" id="idnome" required autocomplete="off">

                <label for="email">Novo email:</label>
                <input type="text" name="email" id="idemail"  autocomplete="off" required>

                <label for="sexo">Informe o sexo novamente:</label>
                <input type="text" name="sexo" id="idsexo"  autocomplete="off" required>

                <input type="submit" value="Atualizar">
            </form>
        </section>


        <section>
            <?php
            
                $servidor = "localhost: 3306";
                $usuario = "root";
                $senha = "";
                $banco = "bancophp";

                

                $conexao = mysqli_connect($servidor, $usuario, $senha, $banco);
                

                mysqli_query($conexao, "
                
                update pessoas set nome = '".$nome."' where cpf = '".$cpf."';
                
                ");

                mysqli_query($conexao, "
                
                update pessoas set email = '".$email."' where cpf='".$cpf."';
                
                
                ");


                mysqli_query($conexao, "
                
                
                update pessoas set sexo = '".$sexo."' where cpf = '".$cpf."';
                
                ");

                echo "<h2> Dados atualizados</h2>";

                echo "<h3> Dados informados</h3>";

                echo "<p> cpf: $cpf</p>";
                echo "<p> nome: $nome</p>";
                echo "<p> email: $email</p>";
                echo "<p> sexo: $sexo</p>";

            
            ?>
        </section>
    </body>
</html>