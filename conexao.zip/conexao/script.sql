

create database bancophp;

use bancophp;

create table pessoas(

	nome text,
    cpf int  not null,
    email text,
    
    primary key (cpf)
)default charset = utf8;

/*Vamos precisar alterar a coluna de sexo para que tenha valor
padrão não informado caso o usuário não passe nenhum valor*/
/*Como estamos com dificuldade de alterar o valor, vamos apagar a coluna
e adiciona-la de novo com as atualizações criadas.*/
ALTER TABLE pessoas 
   drop COLUMN sexo;
   
   alter table pessoas
   add column sexo enum('M', 'F', 'OUTROS', 'm', 'f', 'Outros', 'outros', 'não informado');

/*Código para desabilitar o modo safe do mysql que ira permitir que eu realize
updates e deletes*/
SET SQL_SAFE_UPDATES=0;

update pessoas set nome = 'vargas' where cpf = '9090'; 



select * from pessoas;