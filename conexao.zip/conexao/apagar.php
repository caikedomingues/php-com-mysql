

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <link rel="shotcuts icon" href="imagens/simbolo.png">
        <link rel="stylesheet" href="estilo/estilo.css">
        <title>php com banco de dados</title>
    </head>

    <body>

        <header>

            <h1>php com banco mysql</h1>

        </header>
        <main>
            <p><a href="cadastro.php">Cadastro</a></p>
            <p><a href="atualizar.php">Atualizar</a></p>
            <p><a href="pesquisar.php">Pesquisar usuario</a></p>
            <p><a href="index.html">Voltar a página inicial</a></p>
        </main>

        <section>

            <?php

                /*Captura do valor */
                $cpf = $_GET['cpf'] ?? 0;
            
            ?>
            <form action="<?php $_SERVER = ['PHP_SELF']?>" method="get">

            <label for="cpf">Informe o cpf do usuário que será excluido</label>

            <input type="number" name="cpf" id="idcpf" required>
            
            <input type="submit" value="excluir">
            </form>
        </section>

        <section>
            <?php
            
                /*Nessa parte iremos trabalhar os resultados */

                /*Conexao do banco de dados*/

                $servidor = "localhost";
                $usuario = "root";
                $senha = "";
                $banco = "bancophp";

                $conexao = mysqli_connect($servidor, $usuario, $senha, $banco);

                mysqli_query($conexao, "
                
                    delete from pessoas where cpf = '".$cpf."';
                
                ");

                echo "<p> ultima exclusão: $cpf</p>";

                
            ?>
        </section>
    </body>
</html>