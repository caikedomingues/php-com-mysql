


<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <title>php com banco de dados</title>
        <link rel="stylesheet" href="estilo/estilo.css">
        <link rel="shotcuts icon" href="imagens/simbolo.png">
    <head>

    <body>
        <header>
            <h1>Php com banco de dados mysql</h1>
        </header>

        <main>
            <p><a href="cadastro.php">Cadastro</a></p>
            <p><a href="atualizar.php">Atualizar</a></p>
            <p><a href="apagar.php">Apagar</a></p>
            <p><a href="index.html">Voltar a página inicial</a></p>
        </main>

        <section>

            <?php
                
                $cpf = $_GET['cpf'] ?? 0;
            
            ?>

            <form action="<?php $_SERVER=['PHP_SELF']?>" method="get">

                <label for="cpf">Informe o cpf que você quer pesquisar:</label>

                <input type="number" name="cpf" id="idcpf" required>

                <input type="submit" value="pesquisar">
            </form>
        </section>

        <section>
            <?php
            
            /*aqui iremos trabalhar os resultados */

            /*conexão com o banco de dados */

            $servidor = "localhost";
            $usuario = "root";
            $senha = "";
            $banco = "bancophp";

            $conexao = mysqli_connect($servidor, $usuario, $senha, $banco);

            /*Antes de iniciarmos, devemos chamar o método de seleção do banco de dados que irá ter como parametro */
            mysqli_select_db($conexao, "bancophp");

            $query = "select * from pessoas where cpf='".$cpf."';";

            $result = mysqli_query($conexao, $query);
            
            while($row = mysqli_fetch_array($result)){

                echo "nome: ".$row['nome']."</p>";
                echo "cpf: ".$row['cpf']."</p>";
                echo "email: ".$row['email']."</p>";
                echo "sexo: ".$row['sexo']."</p>";
            };

           
            ?>
        </section>
    </body>
</html>
