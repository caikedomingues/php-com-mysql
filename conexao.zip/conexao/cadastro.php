
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <title>php com banco de dados</title>
        <link rel="shotcuts icon" href="imagens/simbolo.png">
        <link rel="stylesheet" href = "estilo/estilo.css">
    </head>

    <body>

        <header>
            <h1>php com banco de dados mysql</h1>
        </header>

        <main>
                <p><a href="atualizar.php">Atualizar um cadastro</a></p>
                <p><a href="apagar.php">Apagar</a></p>
                <p><a href="pesquisar.php">Pesquisar usuário</a></p>
                <p><a href="index.html">Voltar a página inicial</a></p>
        </main>

        <!--Informações que devem conter no formulário
        id, nome, cpf, email, sexo
        -->
        <section>


            <?php
            
                /*Nessa parte iremos capturar os valores passados pelos usuários*/

                $nome = $_GET['nome']?? "desconhecido";
                $cpf = $_GET['cpf'] ?? 0;
                $email = $_GET['email'] ?? 'Não informado';
                $sexo = $_GET['sexo'] ?? 'Não informado';

            ?>
            <form action = "<?php $_SERVER = ['PHP_SELF'] ?>" method="get">

                <label for="nome"> Nome: </label>

                <input type = "text" name="nome" id="idnome" required  autocomplete="off" required>

                <label for="cpf"> Cpf:</label>
                <input type="number" name="cpf" id="idcpf" required  autocomplete="off" required>
                
                <label for = "email">Email:</label>
                <input type="text" name="email" id="idemail" autocomplete="off" required>

                <label for="sexo">sexo (M, F, OUTROS): </label>
                <input type="text" name="sexo" id="idsexo"  autocomplete="off" required>

                <input type="submit" value="Cadastrar">

            </form>
        </section>

        <section>

            <?php
            
                /*Nessa parte iremos trabalhar a conexao com o banco de dados e a inserção de dados */

                $servidor = "localhost";
                $usuario = "root";
                $senha = "";
                $banco = "bancophp";

                $conexao = mysqli_connect($servidor, $usuario, $senha, $banco);
                
                mysqli_query($conexao, "
                
                    insert into pessoas(nome, cpf, email, sexo) values('".$nome."', '".$cpf."', '".$email."', '".$sexo."');
                ");
                

                echo "<h2> Dados cadastrados </h2>";

                echo "<p>nome: $nome</p>";
                echo "<p> cpf: $cpf</p>";
                echo "<p> email: $email</p>";
                echo "<p>sexo: $sexo</p>";
            ?>
        </section>
    </body>
</html>